import React, { useState, useEffect } from 'react';
import { Phone, Mail, MapPin, Clock, Cloud, Menu, X, CheckCircle, ArrowRight, Scale, Calculator, Users } from 'lucide-react';
import { content } from './data/data.js';
import emailjs from '@emailjs/browser';

// --- COMPONENTE: BARRA SUPERIOR (Hora y Clima REAL) ---
const TopBar = () => {
  const [time, setTime] = useState(new Date());
  const [weather, setWeather] = useState({ temp: '--', desc: 'Cargando...' });

  useEffect(() => {
    // 1. Reloj
    const timer = setInterval(() => setTime(new Date()), 1000);
    
    // 2. Clima API (OpenWeatherMap)
    const fetchWeather = async () => {
      try {
        const apiKey = "63e9d5ac8779664f650b2dd5f221b6ca";
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Madrid&appid=${apiKey}&units=metric&lang=es`);
        const data = await response.json();
        
        if (data.main) {
          // Capitalizar la descripción (ej: "cielo claro" -> "Cielo claro")
          const desc = data.weather[0].description;
          const formattedDesc = desc.charAt(0).toUpperCase() + desc.slice(1);
          
          setWeather({ 
            temp: Math.round(data.main.temp) + '°C', 
            desc: formattedDesc 
          });
        }
      } catch (error) {
        console.error("Error al obtener el clima:", error);
        setWeather({ temp: 'N/A', desc: 'Madrid' });
      }
    };

    fetchWeather();
    // Actualizar clima cada 60 minutos para no gastar la API
    const weatherTimer = setInterval(fetchWeather, 3600000); 

    return () => {
      clearInterval(timer);
      clearInterval(weatherTimer);
    };
  }, []);

  return (
    <div className="bg-brand-dark text-white text-xs py-2 px-4 flex justify-between items-center">
      <div className="flex gap-4">
        <span className="flex items-center gap-1">
          <Clock size={14} className="text-brand-gold"/> {time.toLocaleTimeString()}
        </span>
        <span className="flex items-center gap-1">
          <Cloud size={14} className="text-brand-gold"/> Madrid: {weather.temp} - {weather.desc}
        </span>
      </div>
      <div className="hidden md:flex gap-4">
        <a href="tel:+34910000000" className="hover:text-brand-gold transition">Urgencias: 910 000 000</a>
      </div>
    </div>
  );
};

// --- COMPONENTE: NAVBAR ---
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  const scrollTo = (id) => {
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-24">
          <div className="flex-shrink-0 flex items-center cursor-pointer" onClick={() => window.scrollTo(0,0)}>
            {/* LOGO DE ADGES */}
            <img className="h-16 w-auto object-contain" src="/public/logo ADGES N.png" alt="ADGES Administración" />
          </div>
          
          {/* Menu Desktop */}
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollTo('nosotros')} className="text-gray-700 hover:text-brand-DEFAULT font-medium transition">Sobre Nosotros</button>
            <button onClick={() => scrollTo('servicios')} className="text-gray-700 hover:text-brand-DEFAULT font-medium transition">Servicios</button>
            <button onClick={() => scrollTo('tarifas')} className="text-gray-700 hover:text-brand-DEFAULT font-medium transition">Tarifas</button>
            <button onClick={() => scrollTo('contacto')} className="bg-brand-DEFAULT text-white px-5 py-2 rounded-md hover:bg-brand-dark transition shadow-md border-b-4 border-brand-gold">
              Contáctanos
            </button>
          </div>

          {/* Menu Mobile Button */}
          <div className="flex items-center md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-700">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col">
            <button onClick={() => scrollTo('nosotros')} className="block px-3 py-2 text-base font-medium text-gray-700">Sobre Nosotros</button>
            <button onClick={() => scrollTo('servicios')} className="block px-3 py-2 text-base font-medium text-gray-700">Servicios</button>
            <button onClick={() => scrollTo('tarifas')} className="block px-3 py-2 text-base font-medium text-gray-700">Tarifas</button>
            <button onClick={() => scrollTo('contacto')} className="block px-3 py-2 text-base font-medium text-brand-DEFAULT font-bold">Contáctanos</button>
          </div>
        </div>
      )}
    </nav>
  );
};

// --- COMPONENTE: HERO DINÁMICO ---
const Hero = () => {
  const images = [
    "https://images.unsplash.com/photo-1539037116277-4db20889f2d4?auto=format&fit=crop&q=80&w=1920", 
    "https://images.unsplash.com/photo-1543783207-ec64e4d95325?auto=format&fit=crop&q=80&w=1920", 
    "https://images.unsplash.com/photo-1572370076751-6d42da574d71?auto=format&fit=crop&q=80&w=1920"  
  ];
  const [currentImg, setCurrentImg] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImg((prev) => (prev + 1) % images.length);
    }, 60000); 
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative h-[600px] flex items-center justify-center text-center text-white">
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out"
        style={{ backgroundImage: `url(${images[currentImg]})` }}
      >
        <div className="absolute inset-0 bg-brand-dark/60"></div> {/* Overlay con el color de la marca */}
      </div>
      
      <div className="relative z-10 px-4 max-w-4xl animate-fade-in-up">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 drop-shadow-lg tracking-tight">
          ADGES <span className="text-brand-gold">Administración</span>
        </h1>
        <p className="text-xl md:text-3xl font-light italic mb-8">"Hacemos de tu comunidad un hogar"</p>
        <button onClick={() => document.getElementById('contacto').scrollIntoView()} className="bg-white text-brand-DEFAULT px-8 py-3 rounded-full font-bold hover:bg-brand-gold hover:text-white transition-all shadow-lg transform hover:scale-105">
            Solicitar Presupuesto
        </button>
      </div>
    </div>
  );
};

// --- SECCIONES PRINCIPALES ---
const About = () => (
  <section id="nosotros" className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
      <div className="relative">
        <img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&q=80&w=800" alt="Reunión familiar" className="rounded-lg shadow-2xl w-full object-cover h-96 border-b-8 border-brand-gold"/>
        <div className="absolute -bottom-6 -right-6 bg-brand-DEFAULT text-white p-6 rounded-lg shadow-lg hidden md:block">
          <p className="font-bold text-3xl text-brand-gold">20+</p>
          <p className="text-sm">Años de experiencia</p>
        </div>
      </div>
      <div>
        <h2 className="text-3xl font-bold text-gray-800 mb-6 border-l-4 border-brand-gold pl-4">Sobre Nosotros</h2>
        <p className="text-gray-600 text-lg leading-relaxed">{content.about.text}</p>
        <div className="mt-6 grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 text-brand-DEFAULT font-semibold"><Users className="text-brand-gold"/> Trato Familiar</div>
            <div className="flex items-center gap-2 text-brand-DEFAULT font-semibold"><CheckCircle className="text-brand-gold"/> Transparencia</div>
        </div>
      </div>
    </div>
  </section>
);

const Services = () => (
  <section id="servicios" className="py-20 bg-gray-50">
    <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
      <div className="order-2 md:order-1">
        <h2 className="text-3xl font-bold text-gray-800 mb-8 border-l-4 border-brand-gold pl-4">Nuestros Servicios</h2>
        <div className="space-y-6">
          {content.services.map((svc, index) => (
            <div key={index} className="flex gap-4 p-6 bg-white rounded-lg shadow-sm hover:shadow-lg transition-all border-l-4 border-transparent hover:border-brand-gold">
              <div className="text-brand-DEFAULT">
                 {/* Mapeo simple de iconos basado en el índice o nombre */}
                 {index === 0 && <Users size={32} />}
                 {index === 1 && <Calculator size={32} />}
                 {index === 2 && <Scale size={32} />}
              </div>
              <div>
                <h3 className="font-bold text-xl mb-1 text-brand-DEFAULT">{svc.title}</h3>
                <p className="text-gray-600">{svc.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="order-1 md:order-2">
         <img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=800" alt="Servicios Contables" className="rounded-lg shadow-2xl w-full object-cover h-96 border-b-8 border-brand-gold"/>
      </div>
    </div>
  </section>
);

const Pricing = () => (
  <section id="tarifas" className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <div>
           <img src="https://images.unsplash.com/photo-1460317442991-0ec209397118?auto=format&fit=crop&q=80&w=800" alt="Comunidad feliz" className="rounded-lg shadow-2xl w-full h-96 object-cover border-b-8 border-brand-gold"/>
        </div>
        <div>
          <h2 className="text-3xl font-bold text-gray-800 mb-8 border-l-4 border-brand-gold pl-4">Tarifas Transparentes</h2>
          <div className="grid gap-6">
            {content.pricing.map((plan, i) => (
              <div key={i} className={`p-6 rounded-lg border transition-all hover:scale-105 ${i === 1 ? 'border-brand-gold bg-amber-50 shadow-md relative' : 'border-gray-200 bg-white'}`}>
                {i === 1 && <span className="absolute top-0 right-0 bg-brand-gold text-white text-xs font-bold px-2 py-1 rounded-bl-lg">RECOMENDADO</span>}
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-bold text-xl text-brand-DEFAULT">{plan.title}</h3>
                  <div className="text-right">
                    <span className="text-2xl font-bold text-brand-gold">{plan.price}</span>
                    <span className="text-sm text-gray-500 block">{plan.unit}</span>
                  </div>
                </div>
                <ul className="text-sm text-gray-600 space-y-3">
                  {plan.features.map((f, idx) => <li key={idx} className="flex items-center gap-2"><ArrowRight size={14} className="text-brand-gold"/> {f}</li>)}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Contact = () => {
  const sendEmail = (e) => {
    e.preventDefault();
    // emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', e.target, 'YOUR_PUBLIC_KEY')
    alert("¡Mensaje enviado correctamente! El equipo de ADGES contactará contigo pronto.");
    e.target.reset();
  };

  return (
    <section id="contacto" className="py-20 bg-brand-light">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-brand-DEFAULT">Contáctanos</h2>
        
        <div className="grid md:grid-cols-1 gap-12 max-w-4xl mx-auto">
          {/* Formulario */}
          <div className="bg-white p-8 rounded-xl shadow-lg border-t-4 border-brand-gold">
            <form onSubmit={sendEmail} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input type="text" name="name" placeholder="Nombre y Apellidos" required className="p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
              <input type="email" name="email" placeholder="Correo Electrónico" required className="p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
              <input type="text" name="address" placeholder="Dirección" className="p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
              <div className="flex gap-4">
                <input type="text" name="portal" placeholder="Portal" className="w-1/2 p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
                <input type="text" name="floor" placeholder="Piso" className="w-1/2 p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
              </div>
              <input type="text" name="subject" placeholder="Asunto" className="md:col-span-2 p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"/>
              <textarea name="message" placeholder="Expón tu duda o problema aquí..." rows="4" className="md:col-span-2 p-3 bg-gray-50 border border-gray-200 rounded focus:outline-none focus:ring-2 focus:ring-brand-gold focus:bg-white transition"></textarea>
              
              <button type="submit" className="md:col-span-2 bg-brand-DEFAULT text-white py-3 rounded font-bold hover:bg-brand-gold transition shadow-lg">
                Enviar Mensaje al Equipo ADGES
              </button>
            </form>
          </div>
        </div>

        {/* Mapa y Partners */}
        <div className="mt-16 grid md:grid-cols-2 gap-8 items-start">
            <div className="h-80 bg-gray-200 rounded-lg overflow-hidden shadow-md border-2 border-white">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d194348.13980753766!2d-3.819619425420138!3d40.43786976008323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd422997800a3c81%3A0xc436dec1618c2269!2sMadrid!5e0!3m2!1ses!2ses!4v1700000000000!5m2!1ses!2ses" 
                    width="100%" 
                    height="100%" 
                    style={{border:0}} 
                    allowFullScreen="" 
                    loading="lazy">
                </iframe>
            </div>
            
            {/* Socios */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                <h3 className="font-bold text-lg mb-6 text-center text-brand-DEFAULT">Socios Estratégicos</h3>
                <div className="grid grid-cols-2 gap-8 items-center justify-items-center opacity-80">
                    <div className="text-center group cursor-pointer">
                        <div className="h-20 w-20 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto text-brand-DEFAULT group-hover:bg-brand-gold group-hover:text-white transition">
                            <Scale size={40}/>
                        </div>
                        <span className="text-xs font-bold text-gray-500 group-hover:text-brand-DEFAULT">Ilustre Colegio de Abogados</span>
                    </div>
                    <div className="text-center group cursor-pointer">
                        <div className="h-20 w-20 bg-gray-100 rounded-full flex items-center justify-center mb-2 mx-auto text-brand-DEFAULT group-hover:bg-brand-gold group-hover:text-white transition">
                            <CheckCircle size={40}/>
                        </div>
                        <span className="text-xs font-bold text-gray-500 group-hover:text-brand-DEFAULT">Admin. de Fincas Colegiados</span>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="bg-brand-dark text-white py-12 border-t-4 border-brand-gold">
    <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-12">
      <div>
        <div className="flex items-center gap-2 mb-4">
             {/* Logo pequeño en footer si quieres, o solo texto */}
             <img src="/logo.png" className="h-8 brightness-0 invert" alt="ADGES" /> 
             <span className="font-bold text-xl tracking-wider">ADGES</span>
        </div>
        <p className="text-gray-400 text-sm leading-relaxed">
          Más de 20 años comprometidos con la tranquilidad de tu comunidad. 
          Gestión familiar, transparente y eficaz.
        </p>
      </div>
      <div>
        <h4 className="font-bold text-lg mb-6 text-brand-gold">Contacto Directo</h4>
        <div className="space-y-3 text-gray-300">
          <a href="tel:910000000" className="flex items-center gap-3 hover:text-white transition"><Phone size={18} className="text-brand-gold"/> 910 000 000</a>
          <a href="mailto:info@adges.com" className="flex items-center gap-3 hover:text-white transition"><Mail size={18} className="text-brand-gold"/> info@adges.com</a>
          <p className="flex items-center gap-3"><MapPin size={18} className="text-brand-gold"/> Calle Principal 123, Madrid</p>
        </div>
      </div>
      <div>
        <h4 className="font-bold text-lg mb-6 text-brand-gold">Enlaces Legales</h4>
        <ul className="text-sm text-gray-400 space-y-2">
          <li><a href="#" className="hover:text-brand-gold transition">Aviso Legal</a></li>
          <li><a href="#" className="hover:text-brand-gold transition">Política de Privacidad</a></li>
          <li><a href="#" className="hover:text-brand-gold transition">Política de Cookies</a></li>
        </ul>
      </div>
    </div>
    <div className="text-center mt-12 pt-8 border-t border-gray-800 text-gray-500 text-xs">
      © {new Date().getFullYear()} ADGES Administración S.L. Todos los derechos reservados.
    </div>
  </footer>
);

function App() {
  return (
    <div className="font-sans text-gray-800 bg-gray-50">
      <TopBar />
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Pricing />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;